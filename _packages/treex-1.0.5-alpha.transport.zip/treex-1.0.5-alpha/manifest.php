<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bef4370d577d2e0069665af749e1f282',
      'native_key' => 'treex',
      'filename' => 'modNamespace/5195485055c4c6c29428f43ccd43b7a7.vehicle',
      'namespace' => 'treex',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9d485f08428a60cd521a3f676f3537c8',
      'native_key' => 1,
      'filename' => 'modCategory/49a53d180890c97128c29e6989543751.vehicle',
      'namespace' => 'treex',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52428e1c0bd263f854d9ada6048fc1e',
      'native_key' => 'treex.update_form_id',
      'filename' => 'modSystemSetting/e933c10a83d397aa53eb2937d2c0686f.vehicle',
      'namespace' => 'treex',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d134a5bd700dd41ce622162dd946222',
      'native_key' => 'treex.create_form_id',
      'filename' => 'modSystemSetting/653c64821b544cf83e26ed58592540ba.vehicle',
      'namespace' => 'treex',
    ),
  ),
);