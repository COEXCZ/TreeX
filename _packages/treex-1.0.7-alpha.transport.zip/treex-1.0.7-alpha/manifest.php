<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4f3a1d4e06edfadbe20b887172bf43a2',
      'native_key' => 'treex',
      'filename' => 'modNamespace/764a996c6285429d8aeb927fe13794d7.vehicle',
      'namespace' => 'treex',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '60041cc9832a4b23ba994d041f315bb2',
      'native_key' => 1,
      'filename' => 'modCategory/16e6299db16d31ceca9c0813a08cb5a2.vehicle',
      'namespace' => 'treex',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c095d6547a9cb51ad31597f74aa9af43',
      'native_key' => 'treex.update_form_id',
      'filename' => 'modSystemSetting/1df54ecb67e267a8c668f05aba3437b8.vehicle',
      'namespace' => 'treex',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd70da685176286c849d3d68d4eec195d',
      'native_key' => 'treex.create_form_id',
      'filename' => 'modSystemSetting/07dcc391595705010811100d20991a28.vehicle',
      'namespace' => 'treex',
    ),
  ),
);