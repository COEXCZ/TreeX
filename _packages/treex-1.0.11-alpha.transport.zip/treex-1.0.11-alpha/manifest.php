<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5f4f8c955aa65b591deac758009ae5f8',
      'native_key' => 'treex',
      'filename' => 'modNamespace/43981db5a252626a54ed24320c1b5f5e.vehicle',
      'namespace' => 'treex',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '045a255c8ee79d77ecc0df9bb6fdfdb7',
      'native_key' => 1,
      'filename' => 'modCategory/80c6cc64e65c1e92b33823961e125c1e.vehicle',
      'namespace' => 'treex',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04d641c4d072e4a3ead9d375569e7edd',
      'native_key' => 'treex.update_form_id',
      'filename' => 'modSystemSetting/e464f9035f43fb9aa77486b61df91209.vehicle',
      'namespace' => 'treex',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9aa6022b25e560d49275bfcd71d63210',
      'native_key' => 'treex.create_form_id',
      'filename' => 'modSystemSetting/77623a44ca2aab8e817f904cfcfca017.vehicle',
      'namespace' => 'treex',
    ),
  ),
);