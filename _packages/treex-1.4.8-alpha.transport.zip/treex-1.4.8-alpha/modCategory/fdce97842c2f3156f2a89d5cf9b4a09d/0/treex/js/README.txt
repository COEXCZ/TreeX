== How to compile coffee script file into javasctript file

Install Node.JS

Install coffeescript
npm install -g coffee-script

Run in folder with script
coffee --watch --compile treeInit.coffee