<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ce194dd17530d6d573c226f952a47bf6',
      'native_key' => 'treex',
      'filename' => 'modNamespace/cd82b7d71838b6b41f683fa8ed8aac18.vehicle',
      'namespace' => 'treex',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '86f2fecbf1ed09b54e5c0eac9872e22d',
      'native_key' => 1,
      'filename' => 'modCategory/29823d98452e4a68cc07c7267cad8c0e.vehicle',
      'namespace' => 'treex',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87ec2e6dcfaf88f64171102285432cdd',
      'native_key' => 'treex.update_form_id',
      'filename' => 'modSystemSetting/22ef5bd2df3b4eaf047def96a1164384.vehicle',
      'namespace' => 'treex',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '982243470c661935c02010121496a692',
      'native_key' => 'treex.create_form_id',
      'filename' => 'modSystemSetting/a3228272909cafeda6b91b7ba34d183a.vehicle',
      'namespace' => 'treex',
    ),
  ),
);