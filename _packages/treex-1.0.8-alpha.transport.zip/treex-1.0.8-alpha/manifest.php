<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fc78a93dc379d9cd9e1628a070a0f591',
      'native_key' => 'treex',
      'filename' => 'modNamespace/cc1dbcc6430ee309c717b466074ad9b6.vehicle',
      'namespace' => 'treex',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f66a4093f4b3ecd4250fd4a7c8afe6ef',
      'native_key' => 1,
      'filename' => 'modCategory/65b6136db30c02a43eac1fcaf3fc682f.vehicle',
      'namespace' => 'treex',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '963f3c1db1cb80ef3ae6070cc582c314',
      'native_key' => 'treex.update_form_id',
      'filename' => 'modSystemSetting/56cc294d673913be9184c32b28eae930.vehicle',
      'namespace' => 'treex',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b53c5198899d9bc35e0eb56a768644ce',
      'native_key' => 'treex.create_form_id',
      'filename' => 'modSystemSetting/05310da2c485e2e847014e0c045d0fca.vehicle',
      'namespace' => 'treex',
    ),
  ),
);