<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '52df2a9853c2d5c79331d239bf0b3e76',
      'native_key' => 'treex',
      'filename' => 'modNamespace/b632ec0d83fd25743e5f7289fc999080.vehicle',
      'namespace' => 'treex',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6e9360be60d50da62b891ffd4d476815',
      'native_key' => 1,
      'filename' => 'modCategory/86c51295a79fc2e39939e1b2285917c4.vehicle',
      'namespace' => 'treex',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64a0f450f25fbfb469674d1362b1cabe',
      'native_key' => 'treex.update_form_id',
      'filename' => 'modSystemSetting/43bc05407dd07ee1114bf3fff70fddf1.vehicle',
      'namespace' => 'treex',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e73dba5ced999d76274811ffa3341cb0',
      'native_key' => 'treex.create_form_id',
      'filename' => 'modSystemSetting/a3dc07327bfa656d5f5301f9367e2611.vehicle',
      'namespace' => 'treex',
    ),
  ),
);